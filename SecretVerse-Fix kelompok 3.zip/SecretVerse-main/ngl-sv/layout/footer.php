<footer class="bg-blue-950 flex justify-center">
    <div class="m-4 text-white text-sm">
        &copy; Copyright <strong><span>SecretVerse</span></strong>. All Rights Reserved
    </div>
</footer>

<script src="assets/js/main.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>

</html>